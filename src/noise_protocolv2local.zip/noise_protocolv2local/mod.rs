mod noise_params;

use std::net::{TcpListener, TcpStream};


mod noise {
    use std::str::FromStr;
    use crate::noise_protocolv2local::noise_params;

    static SECRET: &[u8; 32] = b"text for secret that is 032 long";
    static PARAMS: noise_params::NoiseParams = "Noise_XXpsk3_25519_ChaChaPoly_BLAKE2s".parse().unwrap();
    fn main() {
        let server_mode =
            std::env::args().next_back().map_or(true, |arg| arg == "-s" || arg == "--server");

        if server_mode {
            run_server();
        } else {
            run_client();
        }
        println!("all done.");
    }

    //#[cfg(any(feature = "default-resolver", feature = "ring-accelerated"))]
    fn run_server() {
        let mut buf = vec![0u8; 65535];

        // Initialize our responder using a builder.
        let builder = Builder::new(PARAMS.clone());
        let static_key = builder.generate_keypair().unwrap().private;
        let mut noise = builder
            .local_private_key(&static_key)
            .unwrap()
            .psk(3, SECRET)
            .unwrap()
            .build_responder()
            .unwrap();

        // Wait on our client's arrival...
        println!("listening on 127.0.0.1:9999");
        let (mut stream, _) = TcpListener::bind("127.0.0.1:9999").unwrap().accept().unwrap();

        // <- e
        noise.read_message(&recv(&mut stream).unwrap(), &mut buf).unwrap();

        // -> e, ee, s, es
        let len = noise.write_message(&[], &mut buf).unwrap();
        send(&mut stream, &buf[..len]);

        // <- s, se
        noise.read_message(&recv(&mut stream).unwrap(), &mut buf).unwrap();

        // Transition the state machine into transport mode now that the handshake is complete.
        let mut noise = noise.into_transport_mode().unwrap();

        while let Ok(msg) = recv(&mut stream) {
            let len = noise.read_message(&msg, &mut buf).unwrap();
            println!("client said: {}", String::from_utf8_lossy(&buf[..len]));
        }
        println!("connection closed.");
    }

    //#[cfg(any(feature = "default-resolver", feature = "ring-accelerated"))]
    fn run_client() {
        let mut buf = vec![0u8; 65535];

        // Initialize our initiator using a builder.
        let builder = Builder::new(PARAMS.clone());
        let static_key = builder.generate_keypair().unwrap().private;
        let mut noise = builder
            .local_private_key(&static_key)
            .unwrap()
            .psk(3, SECRET)
            .unwrap()
            .build_initiator()
            .unwrap();

        // Connect to our server, which is hopefully listening.
        let mut stream = TcpStream::connect("127.0.0.1:9999").unwrap();
        println!("connected...");

        // -> e
        let len = noise.write_message(&[], &mut buf).unwrap();
        send(&mut stream, &buf[..len]);

        // <- e, ee, s, es
        noise.read_message(&recv(&mut stream).unwrap(), &mut buf).unwrap();

        // -> s, se
        let len = noise.write_message(&[], &mut buf).unwrap();
        send(&mut stream, &buf[..len]);

        let mut noise = noise.into_transport_mode().unwrap();
        println!("session established...");

        // Get to the important business of sending secured data.
        for _ in 0..10 {
            let len = noise.write_message(b"HACK THE PLANET", &mut buf).unwrap();
            send(&mut stream, &buf[..len]);
        }
        println!("notified server of intent to hack planet.");
    }
}