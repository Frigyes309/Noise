#[derive(PartialEq, Clone, Debug)]
#[allow(clippy::module_name_repetitions)]
pub struct NoiseParams {
    /// The full pattern string.
    pub name:      String,
    /// In this case, always `Noise`.
    pub base:      BaseChoice,
    /// The pattern's handshake choice (e.g. `XX`).
    pub handshake: HandshakeChoice,
    /// The pattern's DH choice (e.g. `25519`).
    pub dh:        DHChoice,
    #[cfg(feature = "hfs")]
    /// The pattern's KEM choice (e.g. `Kyber1024`).
    pub kem:       Option<KemChoice>,
    /// The pattern's cipher choice (e.g. `AESGCM`).
    pub cipher:    CipherChoice,
    /// The pattern's hash choice (e.g. `SHA256`).
    pub hash:      HashChoice,
}

impl NoiseParams {
    #[cfg(not(feature = "hfs"))]
    /// Construct a new `NoiseParams` via specifying enums directly.
    #[must_use]
    pub fn new(
        name: String,
        base: BaseChoice,
        handshake: HandshakeChoice,
        dh: DHChoice,
        cipher: CipherChoice,
        hash: HashChoice,
    ) -> Self {
        NoiseParams { name, base, handshake, dh, cipher, hash }
    }

    #[cfg(feature = "hfs")]
    /// Construct a new NoiseParams via specifying enums directly.
    pub fn new(
        name: String,
        base: BaseChoice,
        handshake: HandshakeChoice,
        dh: DHChoice,
        kem: Option<KemChoice>,
        cipher: CipherChoice,
        hash: HashChoice,
    ) -> Self {
        NoiseParams { name, base, handshake, dh, kem, cipher, hash }
    }
}